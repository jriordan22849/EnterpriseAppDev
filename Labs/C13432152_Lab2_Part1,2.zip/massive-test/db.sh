#!/bin/bash

psql --dbname pgguide
